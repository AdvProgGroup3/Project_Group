package project;
import java.util.*;
public class AList {
	public List getList(){
		List a= new ArrayList();
		a.add(10);
		return a;
	}
}
